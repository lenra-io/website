// Place fonts/Lenra-icons.ttf in your fonts/ directory and
// add the following to your pubspec.yaml
// flutter:
//   fonts:
//    - family: Lenra-icons
//      fonts:
//       - asset: fonts/Lenra-icons.ttf
import 'package:flutter/widgets.dart';

class Lenra_icons {
  Lenra_icons._();

  static const String _fontFamily = 'Lenra-icons';

  static const IconData logo_lenra = IconData(0xe92e, fontFamily: _fontFamily);
  static const IconData webhooks = IconData(0xe92f, fontFamily: _fontFamily);
  static const IconData cron = IconData(0xe930, fontFamily: _fontFamily);
  static const IconData tiktok = IconData(0xe934, fontFamily: _fontFamily);
  static const IconData twitch = IconData(0xe933, fontFamily: _fontFamily);
  static const IconData dev_dot_to = IconData(0xe90b, fontFamily: _fontFamily);
  static const IconData reddit = IconData(0xe90a, fontFamily: _fontFamily);
  static const IconData github = IconData(0xe904, fontFamily: _fontFamily);
  static const IconData instagram = IconData(0xe905, fontFamily: _fontFamily);
  static const IconData linkedin = IconData(0xe906, fontFamily: _fontFamily);
  static const IconData twitter = IconData(0xe907, fontFamily: _fontFamily);
  static const IconData youtube = IconData(0xe908, fontFamily: _fontFamily);
  static const IconData android = IconData(0xe925, fontFamily: _fontFamily);
  static const IconData ios = IconData(0xe926, fontFamily: _fontFamily);
  static const IconData apple = IconData(0xe927, fontFamily: _fontFamily);
  static const IconData linux = IconData(0xe928, fontFamily: _fontFamily);
  static const IconData windows = IconData(0xe929, fontFamily: _fontFamily);
  static const IconData devices = IconData(0xe931, fontFamily: _fontFamily);
  static const IconData auto_scaling = IconData(0xe932, fontFamily: _fontFamily);
  static const IconData cpu = IconData(0xe920, fontFamily: _fontFamily);
  static const IconData terminal = IconData(0xe921, fontFamily: _fontFamily);
  static const IconData database = IconData(0xe923, fontFamily: _fontFamily);
  static const IconData at_sign = IconData(0xe900, fontFamily: _fontFamily);
  static const IconData send = IconData(0xe901, fontFamily: _fontFamily);
  static const IconData mail = IconData(0xe902, fontFamily: _fontFamily);
  static const IconData chevron_down = IconData(0xe92a, fontFamily: _fontFamily);
  static const IconData chevron_left = IconData(0xe92b, fontFamily: _fontFamily);
  static const IconData chevron_right = IconData(0xe92c, fontFamily: _fontFamily);
  static const IconData chevron_up = IconData(0xe92d, fontFamily: _fontFamily);
  static const IconData arrow_up = IconData(0xe917, fontFamily: _fontFamily);
  static const IconData arrow_up_left = IconData(0xe918, fontFamily: _fontFamily);
  static const IconData arrow_left = IconData(0xe919, fontFamily: _fontFamily);
  static const IconData arrow_down_left = IconData(0xe91a, fontFamily: _fontFamily);
  static const IconData arrow_down = IconData(0xe91b, fontFamily: _fontFamily);
  static const IconData arrow_down_right = IconData(0xe91c, fontFamily: _fontFamily);
  static const IconData arrow_right = IconData(0xe916, fontFamily: _fontFamily);
  static const IconData arrow_up_right = IconData(0xe91d, fontFamily: _fontFamily);
  static const IconData activity = IconData(0xe91e, fontFamily: _fontFamily);
  static const IconData layers = IconData(0xe91f, fontFamily: _fontFamily);
  static const IconData bell = IconData(0xe922, fontFamily: _fontFamily);
  static const IconData grid = IconData(0xe924, fontFamily: _fontFamily);
  static const IconData book_open = IconData(0xe903, fontFamily: _fontFamily);
  static const IconData check_circle = IconData(0xe90c, fontFamily: _fontFamily);
  static const IconData clock = IconData(0xe90d, fontFamily: _fontFamily);
  static const IconData dollar_sign = IconData(0xe910, fontFamily: _fontFamily);
  static const IconData folder = IconData(0xe911, fontFamily: _fontFamily);
  static const IconData list = IconData(0xe912, fontFamily: _fontFamily);
  static const IconData mouse_pointer = IconData(0xe913, fontFamily: _fontFamily);
  static const IconData sun = IconData(0xe914, fontFamily: _fontFamily);
  static const IconData users = IconData(0xe915, fontFamily: _fontFamily);
  static const IconData shield = IconData(0xe90e, fontFamily: _fontFamily);
  static const IconData star = IconData(0xe90f, fontFamily: _fontFamily);
}
